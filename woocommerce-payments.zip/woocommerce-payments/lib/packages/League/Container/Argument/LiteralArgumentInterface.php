<?php

declare(strict_types=1);

namespace WCPay\Vendor\League\Container\Argument;

interface LiteralArgumentInterface extends ArgumentInterface
{
}
