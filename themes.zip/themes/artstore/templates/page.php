<?php

/**
 * Template Name: Artist Template
 * Template Post Type: page 
 */
get_header();
?>
<div class="container">
<?php if (has_post_thumbnail()) : ?>
    <div class="featured-image">
        <?php the_post_thumbnail(); ?>
    </div>
<?php endif; ?>
<section>
    <h1><?php echo the_title(); ?></h1>
    <?php echo get_the_content(); ?>
</section>
</div>
<?php
get_footer();
?>