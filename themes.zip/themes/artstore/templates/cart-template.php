<?php

/**
 * Template Name: Cart Page
 * Template Post Type: page
 */
get_header();
?>
<section>
    <h1><?php echo the_title(); ?></h1>
    <?php
  
    echo do_shortcode( '[woocommerce_checkout]' );
    ?>
</section>
<?php
get_footer();
?>