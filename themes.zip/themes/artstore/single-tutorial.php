<?php
get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">

        <?php
        while ( have_posts() ) :
            the_post();
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="post-thumbnail">
                            <?php the_post_thumbnail( 'thumbnail' );?>
                        </div>
                    <?php endif; ?>

                    <div class="entry-meta">
                        <?php
                        get_the_author_posts_link();
                        get_the_date();
                        ?>
                    </div>
                </header><div class="entry-content">
                    <?php the_content(); ?>
                    <?php
                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'your-theme-textdomain' ),
                            'after'  => '</div>',
                        )
                    );

            // If comments are open or we have at least one comment, load the comment template.
            if ( comments_open() || get_comments_number() ) :
                comments_template();
            endif;

        endwhile;
        ?>

    </main></div><?php
get_footer();