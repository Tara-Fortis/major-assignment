<?php
get_header();
?>

<div id="primary" class="content-area">

        <header class="page-header">
            <h1 class="page-title"><?php _e('Tutorials', 'creative-canopy-tutorials'); ?></h1>
            <?php the_archive_description('<div class="taxonomy-description">', '</div>'); ?>
        </header><?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-thumbnail">
                            <?php the_post_thumbnail('medium'); ?>
                        </div>
                    <?php endif; ?>

                    <h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>

                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                </article><?php endwhile; ?>

            <?php the_posts_navigation(); // For navigating between pages of tutorials 
            ?>

        <?php else : ?>
            <?php get_template_part('template-parts/content', 'none'); ?>
        <?php endif; ?>
</div>
<?php
get_footer();
?>