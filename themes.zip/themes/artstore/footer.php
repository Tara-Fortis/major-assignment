<footer>
        <div>
        <?php
            wp_nav_menu(array(
                'menu'                  => 'footer',
                'theme_location'        => '',
                'depth'                 => 2,
                'fallback_cb'           => false
            ));
            ?>
        </div>

        </footer>
    </body>
</html>