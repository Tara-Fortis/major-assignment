<?php

/**
 * Functions for the Creative Canopy theme.
 */

// Theme Setup
function creative_canopy_theme_setup()
{
    // Enable menus
    register_nav_menus(array(
        'header' => 'Header menu',
        'footer' => 'Footer menu'
    ));

    // WooCommerce support
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    // Enable custom background
    add_theme_support('custom-background');

    // Enable featured images
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'creative_canopy_theme_setup');

// Enqueue scripts
function enqueue_wc_cart_fragments()
{
    wp_enqueue_script('wc-cart-fragments');
}
add_action('wp_enqueue_scripts', 'enqueue_wc_cart_fragments');

// Register custom post type
function create_tutorial_post_type()
{
    $labels = array(
        'name'               => _x('Tutorials', 'post type general name', 'creative-canopy-tutorials'),
        'singular_name'      => _x('Tutorial', 'post type singular name', 'creative-canopy-tutorials'),
        'menu_name'          => _x('Tutorials', 'admin menu', 'creative-canopy-tutorials'),
        'name_admin_bar'     => _x('Tutorial', 'add new on admin bar', 'creative-canopy-tutorials'),
        'add_new'            => _x('Add New', 'tutorial', 'creative-canopy-tutorials'),
        'add_new_item'       => __('Add New Tutorial', 'creative-canopy-tutorials'),
        'new_item'           => __('New Tutorial', 'creative-canopy-tutorials'),
        'edit_item'          => __('Edit Tutorial', 'creative-canopy-tutorials'),
        'view_item'          => __('View Tutorial', 'creative-canopy-tutorials'),
        'all_items'          => __('All Tutorials', 'creative-canopy-tutorials'),
        'search_items'       => __('Search Tutorials', 'creative-canopy-tutorials'),
        'parent_item_colon'  => __('Parent Tutorials:', 'creative-canopy-tutorials'),
        'not_found'          => __('No tutorials found.', 'creative-canopy-tutorials'),
        'not_found_in_trash' => __('No tutorials found in Trash.', 'creative-canopy-tutorials'),
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'tutorials'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-lightbulb',
        'supports'           => array('title', 'editor', 'thumbnail', 'revisions', 'author'),
        'taxonomies'         => array('category', 'post_tag'),
    );

    register_post_type('tutorial', $args);
}
add_action('init', 'create_tutorial_post_type');
// Shortcode to display tutorial date
function tutorial_date_shortcode() {
    if ( is_singular( 'tutorial' ) ) {
        $post_date = get_the_date();
        $output = '<p class="tutorial-date">Published on: ' . esc_html( $post_date ) . '</p>';
        return $output;
    } else {
        return '';
    }
}
add_shortcode( 'tutorial_date', 'tutorial_date_shortcode' );
?>