<?php

namespace PaymentPlugins\PPCP\FunnelKit\Checkout\Compatibility;

class PayPal extends AbstractGateway {

	protected $id = 'wc_ppcp';
}