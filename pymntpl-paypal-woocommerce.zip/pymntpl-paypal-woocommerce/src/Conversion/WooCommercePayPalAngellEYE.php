<?php

namespace PaymentPlugins\WooCommerce\PPCP\Conversion;

class WooCommercePayPalAngellEYE extends GeneralPayPalPlugin {

	public $id = 'paypal_express';

	protected $payment_token_id = '_payment_tokens_id';

}