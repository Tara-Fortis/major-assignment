<?php
/**
 * WooCommerce Admin Dummy File
 *
 * This file is here only for bw compatibility: https://github.com/woocommerce/woocommerce/pull/32869
 *
 * @package WooCommerce\Admin
 * @version 6.9.0
 */

